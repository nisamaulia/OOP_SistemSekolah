/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sisfosekolah;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
/**
 *
 * @author nisamauliaazahra
 */
public class SisfoSekolah {
    Connection con;
    Statement stm;
    private static final String user = "root";
    private static final String pass = "";
    private static final String url = "jdbc:mysql://localhost:3306/tubes_pbo";

    public void config() {
        try {
            con = DriverManager.getConnection(url,user, pass);
            System.out.println("Connected");
            stm = con.createStatement();
            

        } catch (Exception e) {
            System.out.println("Error"+e.getLocalizedMessage());
            System.err.println(e);
        }
    }
    public static void main(String[] args) {
        
        Login login = new Login();
        login.setVisible(true);
        

        
        
//        String role = login.jComboBox1.getSelectedItem().toString();
//        if (role == "Siswa"){
//            page_siswa.setVisible(true);
//        } else if (role == "Guru"){
//            page_guru.setVisible(true);
//        } else {
//            page_admin.setVisible(true);
//        }
    }
   
}
