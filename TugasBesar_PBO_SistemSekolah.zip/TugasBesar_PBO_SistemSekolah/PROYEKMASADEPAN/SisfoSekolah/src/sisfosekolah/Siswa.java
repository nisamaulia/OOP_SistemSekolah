/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sisfosekolah;

/**
 *
 * @author nisamauliaazahra
 */
public final class Siswa extends Akun implements LihatData {
    int kelas, nis;
    Guru walikelas;
    MataPelajaran mapel;
    
    public Siswa(String username, String password,String role, String nama, int nis, int kelas, Guru walikelas){
        super(role, nama, username, password);
        setNis(nis);
        setKelas(kelas);
        setWalikelas(walikelas);
    }

    public MataPelajaran getMapel() {
        return mapel;
    }

    public void setMapel(MataPelajaran mapel) {
        this.mapel = mapel;
    }

    public int getKelas() {
        return kelas;
    }

    public void setKelas(int kelas) {
        this.kelas = kelas;
    }

    public int getNis() {
        return nis;
    }

    public void setNis(int nis) {
        this.nis = nis;
    }

    public Guru getWalikelas() {
        return walikelas;
    }

    public void setWalikelas(Guru walikelas) {
        this.walikelas = walikelas;
    }

    public void LihatNilai(MataPelajaran mapel){
        
    }
    
}
