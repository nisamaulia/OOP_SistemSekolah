/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sisfosekolah;

/**
 *
 * @author nisamauliaazahra
 */
public final class WaliMurid extends Database{

    Siswa siswa;
    Raport nilai;
    
    public WaliMurid(String role, String nama, Siswa siswa, Raport nilai){
        super(role,nama);
        setSiswa(siswa);
        setNilai(nilai);
    }
    public Siswa getSiswa() {
        return siswa;
    }

    public void setSiswa(Siswa siswa) {
        this.siswa = siswa;
    }

    public Raport getNilai() {
        return nilai;
    }

    public void setNilai(Raport nilai) {
        this.nilai = nilai;
    }
    
    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
    
}
