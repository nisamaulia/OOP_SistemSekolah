/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sisfosekolah;

/**
 *
 * @author nisamauliaazahra
 */
public final class Sistem {
    Siswa nama_siswa;
    Guru wali_kelas;
    MataPelajaran mapel;
    
    public Sistem(Siswa nama_siswa, Guru wali_kelas, MataPelajaran mapel){
        setNama_siswa(nama_siswa);
        setWali_kelas(wali_kelas);
        setMapel(mapel);
    }

    public Siswa getNama_siswa() {
        return nama_siswa;
    }

    public void setNama_siswa(Siswa nama_siswa) {
        this.nama_siswa = nama_siswa;
    }

    public Guru getWali_kelas() {
        return wali_kelas;
    }

    public void setWali_kelas(Guru wali_kelas) {
        this.wali_kelas = wali_kelas;
    }

    public MataPelajaran getMapel() {
        return mapel;
    }

    public void setMapel(MataPelajaran mapel) {
        this.mapel = mapel;
    }
    
    
}
