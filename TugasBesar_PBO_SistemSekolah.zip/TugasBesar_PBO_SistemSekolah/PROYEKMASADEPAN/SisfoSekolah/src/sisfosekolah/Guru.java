/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sisfosekolah;

/**
 *
 * @author nisamauliaazahra
 */
public final class Guru extends Akun implements LihatData {
    int kelas, nip;
    
    
    public Guru(String username, String password,String role, String nama, int nip, int kelas){
        super(role, nama, username, password);
        setNip(nip);
        setKelas(kelas);
    }

    public int getKelas() {
        return kelas;
    }

    public void setKelas(int kelas) {
        this.kelas = kelas;
    }

    public int getNip() {
        return nip;
    }

    public void setNip(int nip) {
        this.nip = nip;
    }

    
    
}
