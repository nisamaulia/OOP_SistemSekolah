/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sisfosekolah;

/**
 *
 * @author nisamauliaazahra
 */
public class Database{
    String role, nama;
    
    public Database(String role, String nama){
        setRole(role);
        setNama(nama);
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
    
    
}
