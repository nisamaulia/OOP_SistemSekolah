/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sisfosekolah;

/**
 *
 * @author nisamauliaazahra
 */
public final class Raport {
    String nilai_akhir, status;
    MataPelajaran mapel;
    
    public Raport(String nilai_akhir, String status, MataPelajaran mapel){
        setNilai_akhir(nilai_akhir);
        setStatus(status);
        setMapel(mapel);
    }

    public String getNilai_akhir() {
        return nilai_akhir;
    }

    public void setNilai_akhir(String nilai_akhir) {
        this.nilai_akhir = nilai_akhir;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public MataPelajaran getMapel() {
        return mapel;
    }

    public void setMapel(MataPelajaran mapel) {
        this.mapel = mapel;
    }
}
