/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sisfosekolah;

/**
 *
 * @author nisamauliaazahra
 */
public final class MataPelajaran extends Database {
    int kode_mapel;
    Guru pengajar;
    String kumulasi_nilai;
    
    public MataPelajaran(String role, String nama, int kode_mapel, Guru pengajar, String kumulasi_nilai){
        super(role,nama);
        setKode_mapel(kode_mapel);
        setPengajar(pengajar);
        setKumulasi_nilai(kumulasi_nilai);
    }

    public int getKode_mapel() { return kode_mapel; }

    public void setKode_mapel(int kode_mapel) {
        this.kode_mapel = kode_mapel;
    }

    public Guru getPengajar() {
        return pengajar;
    }

    public void setPengajar(Guru pengajar) {
        this.pengajar = pengajar;
    }

    public String getKumulasi_nilai() {
        return kumulasi_nilai;
    }

    public void setKumulasi_nilai(String kumulasi_nilai) {
        this.kumulasi_nilai = kumulasi_nilai;
    }
    
    
}
