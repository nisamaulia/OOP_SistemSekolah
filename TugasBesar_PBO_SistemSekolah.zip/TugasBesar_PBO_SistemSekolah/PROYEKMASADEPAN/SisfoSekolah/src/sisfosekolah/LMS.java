/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sisfosekolah;
import java.time.LocalDate;
/**
 *
 * @author nisamauliaazahra
 */
public final class LMS {
    LocalDate deadline;
    String jenis_tugas;
    int nilai;
    MataPelajaran mapel;
    
    public LMS(LocalDate deadline, String jenis_tugas, int nilai, MataPelajaran mapel){
        setDeadline(deadline);
        setJenis_tugas(jenis_tugas);
        setNilai(nilai);
        setMapel(mapel);
    }

    public LocalDate getDeadline() {
        return deadline;
    }

    public void setDeadline(LocalDate deadline) {
        this.deadline = deadline;
    }

    public String getJenis_tugas() {
        return jenis_tugas;
    }

    public void setJenis_tugas(String jenis_tugas) {
        this.jenis_tugas = jenis_tugas;
    }

    public int getNilai() {
        return nilai;
    }

    public void setNilai(int nilai) {
        this.nilai = nilai;
    }

    public MataPelajaran getMapel() {
        return mapel;
    }

    public void setMapel(MataPelajaran mapel) {
        this.mapel = mapel;
    }
    
    
}
