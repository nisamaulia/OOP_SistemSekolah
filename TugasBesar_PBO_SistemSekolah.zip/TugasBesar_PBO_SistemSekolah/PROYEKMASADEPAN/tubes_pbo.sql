-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 16, 2022 at 05:30 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tubes_pbo`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `nama` varchar(25) NOT NULL,
  `id` int(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`nama`, `id`, `username`, `password`) VALUES
('Nisa Maulia  ', 1301194136, 'nisa', 'nisa'),
('Pramaishella ARP', 1301194105, 'shella', 'shella'),
('Jerry Cahyo', 1301194022, 'jerry', 'jerry'),
('Eka Yahya', 1301190343, 'eka', 'eka');

-- --------------------------------------------------------

--
-- Table structure for table `guru`
--

CREATE TABLE `guru` (
  `nama` varchar(17) CHARACTER SET utf8mb4 NOT NULL,
  `nip` varchar(10) NOT NULL,
  `username` varchar(12) DEFAULT NULL,
  `password` varchar(12) DEFAULT NULL,
  `kelas` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `guru`
--

INSERT INTO `guru` (`nama`, `nip`, `username`, `password`, `kelas`) VALUES
('Malik Narendra ', '303020203', 'malik', 'malik', '5'),
('Nur Albirru', '303020202', 'nur', 'nur02', '6'),
('sample1', '1', 'username', 'password', '1');

-- --------------------------------------------------------

--
-- Table structure for table `mata_pelajaran`
--

CREATE TABLE `mata_pelajaran` (
  `id` int(25) NOT NULL,
  `nama_mapel` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mata_pelajaran`
--

INSERT INTO `mata_pelajaran` (`id`, `nama_mapel`) VALUES
(1, 'Agama'),
(7, 'Bahasa Indonesia'),
(4, 'IPA'),
(3, 'IPS'),
(5, 'PJOK'),
(2, 'PKN'),
(6, 'Seni Budaya');

-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE `nilai` (
  `nis` varchar(25) NOT NULL,
  `nama_mapel` varchar(25) NOT NULL,
  `nilaiakhir` int(11) NOT NULL,
  `pengajar` varchar(17) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nilai`
--

INSERT INTO `nilai` (`nis`, `nama_mapel`, `nilaiakhir`, `pengajar`) VALUES
('101020201', 'PKN', 68, 'sample1'),
('1010202007', 'Agama', 78, 'Nur Albirru'),
('1010202006', 'IPS', 79, 'Malik Narendra '),
('1010202006', 'IPA', 80, 'Malik Narendra '),
('1010202007', 'Bahasa Indonesia', 83, 'Nur Albirru'),
('101020202', 'Agama', 86, 'sample1'),
('101020202', 'PKN', 88, 'sample1'),
('101020201', 'Agama', 90, 'sample1');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `nama` varchar(22) DEFAULT NULL,
  `nis` varchar(25) CHARACTER SET utf8mb4 NOT NULL,
  `kelas` varchar(5) DEFAULT NULL,
  `username` varchar(14) DEFAULT NULL,
  `password` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`nama`, `nis`, `kelas`, `username`, `password`) VALUES
('Adyatma Mahavir', '1010202003', '1', 'adya', 'adya123'),
('Alister Bagaskara', '1010202004', '2', 'bagas', 'bagas675'),
('Ghali Daniyal', '1010202005', '4', 'ghali', 'gh4l1'),
('Radeya Bramantio', '1010202006', '5', 'bramantyo', 'tyoo673'),
('Adiva Arsyila', '1010202007', '6', 'adiva', 'adivaaa'),
('Naila Taleetha', '1010202008', '6', 'naila', 'nailatalee'),
('Alex Chandra', '101020201', '3', 'alex', 'alex'),
('Nanda Syta', '101020202', '3', 'nanda', 'nanda');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`nama`);

--
-- Indexes for table `mata_pelajaran`
--
ALTER TABLE `mata_pelajaran`
  ADD PRIMARY KEY (`nama_mapel`);

--
-- Indexes for table `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`nilaiakhir`),
  ADD KEY `nis` (`nis`),
  ADD KEY `pengajar` (`pengajar`),
  ADD KEY `nama_mapel` (`nama_mapel`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`nis`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `nilai`
--
ALTER TABLE `nilai`
  ADD CONSTRAINT `nilai_ibfk_2` FOREIGN KEY (`nis`) REFERENCES `siswa` (`nis`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `nilai_ibfk_3` FOREIGN KEY (`pengajar`) REFERENCES `guru` (`nama`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `nilai_ibfk_4` FOREIGN KEY (`nama_mapel`) REFERENCES `mata_pelajaran` (`nama_mapel`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `nilai_ibfk_5` FOREIGN KEY (`pengajar`) REFERENCES `guru` (`nama`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
